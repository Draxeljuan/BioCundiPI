package com.appbioc.biocundi_pi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BioCundiPiApplication {

	public static void main(String[] args) {
		SpringApplication.run(BioCundiPiApplication.class, args);
	}

}
