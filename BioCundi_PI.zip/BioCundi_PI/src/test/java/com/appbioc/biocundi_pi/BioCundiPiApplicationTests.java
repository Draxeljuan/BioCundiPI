package com.appbioc.biocundi_pi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BioCundiPiApplicationTests {

	@Test
	void contextLoads() {
	}

}
